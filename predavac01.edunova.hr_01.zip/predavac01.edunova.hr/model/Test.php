<?php

class Test
{
    public static function izvediTest()
    {
     echo 'test';   
    }
}